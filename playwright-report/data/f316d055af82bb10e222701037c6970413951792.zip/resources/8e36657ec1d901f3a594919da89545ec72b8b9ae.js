;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="bd8f65e2-719e-a91f-6803-772ab38e9b81")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/LandingQuickReframe.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_05f705d8._.js",
  "static/chunks/components_LandingQuickReframe_tsx_8f9a74d4._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/LandingQuickReframe.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);

//# debugId=bd8f65e2-719e-a91f-6803-772ab38e9b81