(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_bac49f15._.js",
  "static/chunks/node_modules_next_dist_compiled_react-dom_1e674e59._.js",
  "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_9212ccad._.js",
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_1dd7fb59.js",
  "static/chunks/node_modules_next_dist_compiled_16962a53._.js",
  "static/chunks/node_modules_next_dist_shared_lib_ba7d45f4._.js",
  "static/chunks/node_modules_next_dist_client_e6ad3705._.js",
  "static/chunks/node_modules_next_dist_617d3e51._.js",
  "static/chunks/node_modules_next_router_9e4be07f.js",
  "static/chunks/node_modules_@sentry_core_build_esm_15a73622._.js",
  "static/chunks/node_modules_@sentry_browser_build_npm_esm_dev_c72088ae._.js",
  "static/chunks/node_modules_@sentry-internal_browser-utils_build_esm_c51e76d8._.js",
  "static/chunks/node_modules_@sentry-internal_replay_build_npm_esm_index_32be9d39.js",
  "static/chunks/node_modules_cc19edb7._.js",
  "static/chunks/instrumentation-client_ts_15a74a80._.js"
],
    source: "entry"
});
